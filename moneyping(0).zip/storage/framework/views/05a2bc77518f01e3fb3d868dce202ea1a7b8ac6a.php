<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Domains</h1>
                <a href="<?php echo e(route('admin.domain.create')); ?>" class="btn btn-primary">Create Domain</a>
                <br /><br />
                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>
                <table class="table">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($domain->id); ?></td>
                            <td><?php echo e($domain->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.domain.edit', $domain->id)); ?>" class="btn btn-secondary">Edit</a>
                                <form action="<?php echo e(route('admin.domain.destroy', $domain->id)); ?>" method="post" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this domain?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <div class="d-flex justify-content-between align-items-center">
                    <p>Showing <?php echo e($domains->count()); ?> out of <?php echo e($domains->total()); ?> domains</p>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item<?php echo e($domains->currentPage() === 1 ? ' disabled' : ''); ?>">
                                <a class="page-link" href="<?php echo e($domains->previousPageUrl()); ?>" tabindex="-1">Previous</a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link" href="#"><?php echo e($domains->currentPage()); ?></a>
                            </li>
                            <li class="page-item<?php echo e($domains->hasMorePages() ? '' : ' disabled'); ?>">
                                <a class="page-link" href="<?php echo e($domains->nextPageUrl()); ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/admin/domain/index.blade.php ENDPATH**/ ?>