<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center mt-5 fw-bold" style="color:#057689">Add Phishing Url To Black List</h2>
        <form action="">
            <div class="row mt-5">   <label for="" class="fw-1 fs-4 text-center mb-3">Enter Url</label></div>

            <div class="row"><input type="text" placeholder="" class="w-75 m-auto form-control" value="" name="Websiteurl"></div>
            <div class="row"><button class="btn btn-secondary w-25 m-auto my-3" style="background-color:#057689">Add</button></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/domain/blacklistView.blade.php ENDPATH**/ ?>