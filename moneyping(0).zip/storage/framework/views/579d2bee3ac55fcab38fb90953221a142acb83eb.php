<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="post" action="<?php echo e(route('auth.edit')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12"><h2>Edit Information</h2></div>
                <div class="col-3">
                    <img src="<?php echo e(asset('storage/avatars/'.auth()->user()->avatar)); ?>" class="w-100 pb-5" alt="profile image">
                </div>
                <div class="col-9">
                    <input
                        class="themecolor px-5 py-2 mt-5 mano border-0"
                        type="file"
                        name="avatar"
                        id="avatar"
                        accept="image/jpeg,image/png"
                        max="20000">
                    <p class="text-dark py-2">Acceptance formats jpg png only max file size will be 20mb</p>
                    <?php $__errorArgs = ["avatar"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-dark">Account Information</h2>
                </div>
                <div class="col-md-3">
                    <label class="text-dark my-3">Name</label>
                </div>
                <div class="col-md-9">
                    <input
                        class="my-3"
                        type="text"
                        name="name"
                        value="<?php echo e(auth()->user()->name); ?>">
                    <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-3">
                    <label class="text-dark my-3">Email</label>
                </div>
                <div class="col-md-9">
                    <input
                        class="my-3"
                        type="text"
                        name="email"
                        value="<?php echo e(auth()->user()->email); ?>">
                    <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:red"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row">
                <button class="btn btn-secondary w-25 m-auto my-3" style="background-color:#057689">Save Changes</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/edit.blade.php ENDPATH**/ ?>