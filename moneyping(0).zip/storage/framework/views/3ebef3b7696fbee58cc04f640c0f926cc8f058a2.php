<?php $__env->startSection('content'); ?>
    <div class="row text-light boxes">
        <div class="col-3 ">
            <a href="/Checkwebsite" class="nav-link">
                <div class="bg-blue shadow my-3 px-3 py-3 rounded-3">
                    <h6>Check Website</h6>
                    <i></i>
                    <h3>10,001</h3>
                    <input type="range">
                </div>
            </a>
        </div>
        <div class="col-3">
            <a href="/Blacklist" class="nav-link">
                <div class="bg-red shadow my-3 px-3 py-3 rounded-3">
                    <h6>Blacklist</h6>
                    <i></i>
                    <h3>5000</h3>
                    <input type="range">
                </div>
            </a>
        </div>
        <div class="col-3">
            <a href="/Feedback" class="nav-link">
                <div class="bg-green shadow my-3 px-3 py-3 rounded-3">
                    <h6>Feedback</h6>
                    <i></i>
                    <h3>2.4k</h3>
                    <input type="range">
                </div>
            </a>
        </div>
        <div class="col-3"></div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>